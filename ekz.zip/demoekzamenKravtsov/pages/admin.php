<?php
session_start();
if(!isset($_SESSION["login"])){
header('Location:login.php');

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Все записи Заявителей</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Здравствуйте, Администратор</h1>
            </header>

        
        <main>
            <h2>Список запросов Заявителей</h2>
            <?php 
               // $id=$_SESSION['id'];
                $orders=[];
                $db=new mysqli ("127.0.0.1","root","","gosuslugi");
                $q="SELECT uslugi.id as uslugi_id, uslugi.usluga_id, uslugi.usluga_date, uslugi.pay_method, uslugi.status, uslugi.created_at, spisok_uslug.name FROM uslugi LEFT JOIN spisok_uslug ON uslugi.usluga_id = spisok_uslug.id ORDER BY created_at";
                $orders=$db->query($q);
                $orders=$orders->fetch_all(MYSQLI_ASSOC);

                if (empty($orders)) {
                    echo ("<p>Услуги не запрашивали</p>");
                } else {
                    echo "<table>";
                    echo "<thead>
                            <tr>
                                <th>Название услуги</th>
                                <th>Дата начала</th>
                                <th>Метод оплаты</th>
                                <th>Статус</th>
                                <th>Дата заявки</th>
                            </tr>
                        </thead>";
                    echo "<tbody>";

                        foreach($orders as $order){

                            echo "<tr>
                                    <td>{$order["name"]}</td>
                                    <td>{$order["usluga_date"]}</td>
                                    <td>{$order["pay_method"]}</td>
                                    <td>{$order["status"]}</td>
                                    <td>{$order["created_at"]}</td>
                                </tr>";
                        }
                    echo "</tbody></table>";

                }

             ?>
        </main>
    </div>




</body>
</html>