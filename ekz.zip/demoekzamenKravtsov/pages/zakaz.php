<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Запросить услугу</title>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<div>
		<div class="container">
			<header>
				<h1>
					Подать заявку на оказание услуги
				</h1>
			</header>
            <form action="../handlers/zakaz_h.php" method="POST">
                 
                 <div class="dropdown">
					
					<label for="cars">Выберите услугу:</label>
						<select class='form-select' id="usluga_id" name="usluga_id">
							<option value="1">Замена паспорта</option>
							<option value="2">Справка о несудимости</option>
							<option value="3">Выписка из ЕГРН</option>
						</select>
					</div>


	            <div class="form-group">
		            <label for="start_date">Желаемая дата оказания услуги</label>
	             	<input type="date" id="usluga_date" name="usluga_date" required>
	            </div>
				<div class="form-group">
					<label>Способ оплаты</label>
					<div class="radio-group">
						<label><input type="radio" name="pay_method" value="online" checked> Онлайн-оплата
						</label>

						<label><input type="radio" name="pay_method" value="terminal"> Оплата через терминал
						</label>
					</div>
				</div>	

		<button type="submit">Отправить заявку</button>

        </form>
        <a href="dashboard.php">Назад</a>
		</div>
	</div>
</body>
</html>


