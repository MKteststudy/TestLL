<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Регистрация на портале Госуслуг</title>
	<link rel="stylesheet" href="../css/style.css">

			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>
<body>
	
	<div class="container-fluid text-center">
		<div class="row p-5">
		
		<div class="form-container col-3 offset-4 text-center border border-info border p-3 border rounded-5 bg-light ">
			<h2 class="display-3">Регистрация</h2>
			<form id="registerForm" action="../handlers/register_h.php" method="POST">
				<div class="form-group">
					<label for="login">Логин:</label>
					<input class="form-control" id="login" name="login" type="text" required>
					<div id="emailHelp" class="form-text">Латиница и цифры, не менее 6 символов</div>

				</div>
				<div class="form-group">
					<label for="password">Пароль:</label>
					<input class="form-control" id="password" name="password" type="password" required>
					<div id="emailHelp" class="form-text">Пароль должен состоять минимум из 8 символов</div>
				</div>
				<div class="form-group">
					<label for="full_name">ФИО:</label>
					<input class="form-control" id="full_name" name="full_name" type="text" required>
					<div id="emailHelp" class="form-text">Символы кириллицы и пробелы</div>
				</div>
				<div class="form-group">
					<label for="phone">Телефон:</label>
					<input class="form-control" id="phone" name="phone" type="tel" required placeholder="+7(XXX)XXX-XX-XX">				
				</div>
				<div class="form-group">
					<label for="email">Email:</label>
					<input class="form-control" id="email" name="email" type="email" required>				
				</div>
<p></p>				
				<button type="submit" class="btn btn-info">Зарегистрироваться</button>
			<p>Уже зарегистрированы? <a href="login.php" class="link-info link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Войти</a></p>
			
			</form>
			</div>
			
		</div>
	</div>

<script src="../js/validation.js"></script>	


</body>
</html>