<?php 

session_start();
$user_id=$_SESSION['id'];
$usluga_id=$_POST['usluga_id'];
$usluga_date=$_POST['usluga_date'];
$pay_method=$_POST['pay_method'];

$db=new mysqli ("127.0.0.1","root","","gosuslugi");
$q="INSERT INTO uslugi (user_id, usluga_id, usluga_date, pay_method) VALUES ('$user_id','$usluga_id','$usluga_date','$pay_method')";
$db->query($q);
 ?>

   <script>
 	location.href="../pages/dashboard.php"
 </script>