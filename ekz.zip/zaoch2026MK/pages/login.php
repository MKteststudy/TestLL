<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Вход - Корочки.есть</title>
	<link rel="stylesheet" href="../css/style.css">

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="row p-5">
		<div class="form-container col-3 offset-4 text-center border border-info border p-3 border rounded-5 bg-light ">
			<h2 class="display-3">Вход в систему</h2>
			<form id="loginForm" action="../handlers/login_h.php" method="POST">
				
				<div class="form-group">
					<label for="login" class="form-label">Логин:</label>
					<input class="form-control" id="login" name="login" type="text" required>
					<div id="emailHelp" class="form-text">Логин должен состоять минимум из 8 символов</div>
				</div>
<p> </p>		
				<div class="form-group">
					<label for="password" class="form-label">Пароль:</label>
					<input class="form-control" id="password" name="password" type="password" required >
				</div>
				
<p> </p>
				<button type="submit" class="btn btn-info" >Войти</button>
			</form>
			<p>Еще не зарегистрированы? <a href="register.php" class="link-info link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Зарегистрироваться</a></p>
		</div>
		</div>
	
	</div>

	<script src="../js/validation.js"></script>	

</body>
</html>
